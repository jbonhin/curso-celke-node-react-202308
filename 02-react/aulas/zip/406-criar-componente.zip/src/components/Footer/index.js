function Footer(){
    return(
        <footer>
            <p>Rodapé</p>
        </footer>
    );
}

export default Footer;