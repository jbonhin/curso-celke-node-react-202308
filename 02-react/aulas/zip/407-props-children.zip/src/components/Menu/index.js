function Menu(){
    return(
        <nav>
            <ul>
                <li>Home</li>
                <li>Sobre</li>
                <li>Contato</li>
            </ul>
        </nav>
    );
}

export default Menu;