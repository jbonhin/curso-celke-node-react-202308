COMO RODAR O PROJETO BAIXADO
Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto React 
### npm run dev


SEQUENCIA PARA CRIAR O PROJETO
Criar o projeto React
### npx create-next-app

Acessar o diretório do projeto
### cd celke

Rodar o projeto React
### npm run dev