function About() {
  return (
    <main>
      <h2>Sobre Celke!</h2>
    </main>
  )
}

export default About;
