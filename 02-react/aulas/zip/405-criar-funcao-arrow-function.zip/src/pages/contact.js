const Contact = () => {
    return(
        <main>
            <h2>Contato Celke!</h2>
        </main>
    )
}

export default Contact;