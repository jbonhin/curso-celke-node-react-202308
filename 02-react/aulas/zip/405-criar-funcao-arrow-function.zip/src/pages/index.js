function Home() {
  return (
    <main>
      <h2>Bem-vindo Celke!</h2>
    </main>
  )
}

export default Home;
