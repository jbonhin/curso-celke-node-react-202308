// Exportar as credenciais do banco de dados

module.exports = {
  "development": {
    "username": "root",
    "password": "",
    "database": "celke",
    "host": "localhost",
    "dialect": "mysql"
  },
  "test": {
    "username": "root",
    "password": "",
    "database": "celke",
    "host": "localhost",
    "dialect": "mysql"
  },
  "production": {
    "username": "root",
    "password": "",
    "database": "celke",
    "host": "localhost",
    "dialect": "mysql"
  }
}
