var inicio = 1;

while(inicio <= 10){
	document.write("Número do cliente: " + inicio + "<br>");
	inicio++;
}