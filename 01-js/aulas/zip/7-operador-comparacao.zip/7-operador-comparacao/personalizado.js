var valorUm = 9;
var valorDois = 9;
document.write("<h2>Operador de comparação: igual a </h2>");
if(valorUm == valorDois){
    document.write(valorUm + " é igual a " + valorDois);
}else{
    document.write(valorUm + " é diferente a " + valorDois);
}

valorUm = 10;
valorDois = 9;
document.write("<h2>Operador de comparação: diferente de </h2>");
if(valorUm != valorDois){
    document.write(valorUm + " é diferente de " + valorDois);
}else{
    document.write(valorUm + " é igual a " + valorDois);
}

valorUm = 7;
valorDois = 9;
document.write("<h2>Operador de comparação: menor que </h2>");
if(valorUm < valorDois){
    document.write(valorUm + " é menor que " + valorDois);
}else{
    document.write(valorUm + " não é menor que " + valorDois);
}

valorUm = 12;
valorDois = 9;
document.write("<h2>Operador de comparação: maior que </h2>");
if(valorUm > valorDois){
    document.write(valorUm + " é maior que " + valorDois);
}else{
    document.write(valorUm + " não é maior que " + valorDois);
}

valorUm = 9;
valorDois = 9;
document.write("<h2>Operador de comparação: menor ou igual a </h2>");
if(valorUm <= valorDois){
    document.write(valorUm + " é menor ou igual a " + valorDois);
}else{
    document.write(valorUm + " não é menor ou igual a " + valorDois);
}

valorUm = 10;
valorDois = 9;
document.write("<h2>Operador de comparação: maior ou igual a </h2>");
if(valorUm >= valorDois){
    document.write(valorUm + " é maior ou igual a " + valorDois);
}else{
    document.write(valorUm + " não é maior ou igual a " + valorDois);
}