var total = 0;

for (i = 1; i <= 5; i++){	
	document.write("Valor da variável i: " + i + "<br>");

	total = total + 2;
	document.write("Valor da variável total: " + total + "<br><hr>");
}