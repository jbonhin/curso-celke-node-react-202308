var qntPessoa = 0;

qntPessoa++;
document.write("Quantidade de pessoa que passaram na escada: " + qntPessoa + "<br>");

var qntPessoaShow = 5000;
qntPessoaShow--;
document.write("Quantidade de lugares vazio no show: " + qntPessoaShow + "<br>");