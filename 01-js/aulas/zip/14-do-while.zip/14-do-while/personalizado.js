var inicio = 11;

do{
	document.write("Número do cliente: " + inicio + "<br>");
	inicio++;
}while (inicio <= 10);